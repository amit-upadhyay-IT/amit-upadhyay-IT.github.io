import coolexp

if __name__ == '__main__':

    # object for JSONExpression for first input
    jsonExp1 = coolexp.JSONExpression('./input1.json')

    pretty_exp = jsonExp1.pretty_print()
    print '\nPretty Print:', pretty_exp
    transfored_exp = jsonExp1.transform_expression()
    print 'Transformed Expression:', transfored_exp
    result = jsonExp1.expression_eval(transfored_exp)
    print 'Solution of Above Expression is:', result, '\n'

    print '------------------------------------------'

    # pass the file path to the constructor
    jsonExp2 = coolexp.JSONExpression('./input2.json')

    pretty = jsonExp2.pretty_print()
    print '\nPretty Print:', pretty
    t_exp = jsonExp2.transform_expression()
    print 'Transformed Expression:', t_exp
    res = jsonExp2.expression_eval(t_exp)
    print 'Solution of above expression:', res, '\n'

    print '------------------------------------------'

    # pass the file path to the constructor
    jsonExp3 = coolexp.JSONExpression('./input3.json')

    pretty = jsonExp3.pretty_print()
    print '\nPretty Print:', pretty
    t_exp = jsonExp3.transform_expression()
    print 'Transformed Expression:', t_exp
    res = jsonExp3.expression_eval(t_exp)
    print 'Solution of above expression:', res, '\n'

    print '------------------------------------------'

    # pass the file path to the constructor
    jsonExp4 = coolexp.JSONExpression('./input4.json')

    pretty = jsonExp4.pretty_print()
    print '\nPretty Print:', pretty
    t_exp = jsonExp4.transform_expression()
    print 'Transformed Expression:', t_exp
    res = jsonExp4.expression_eval(t_exp)
    print 'Solution of above expression:', res, '\n'
