import json


class JSONExpression(object):

    def __init__(self, file_path):
        with open(file_path) as f:
            content = json.load(f)
            self.expression_dict = content
        self.lhs_list, self.op_list, self.rhs_list = self.extract_terms()

    # a utility method to extract the terms from the expression dict (or json)
    # below I am gonna write a recursive function. The call stack of this
    # function can be represented using a skewed tree (as only one branch
    # will be formed in each call). So time complexity is O(m)
    ''' Time= O(m); where m is the number of nested objects in the json'''
    ''' Space=O(n); where n is the number of terms in the expression'''
    def extract_terms_helper(self, exp_dict, lhs_list, op_list, rhs_list):
        # base case: if exp_dict isn't a dictionary
        if not isinstance(exp_dict, dict):
            # if the expression dictionary is not longer a dict then
            # stop exploring that branch
            return
        else:
            # insert the operator in op_list
            op_list.append(exp_dict['op'])
            # check if lhs or rhs is dict, if any one of them is dictionary
            # then insert an empty object there and recursively call this
            # function updating the expression dictionary
            if isinstance(exp_dict['lhs'], dict):
                lhs_list.append('EMP')
                rhs_list.append(exp_dict['rhs'])
                self.extract_terms_helper(exp_dict['lhs'], lhs_list, op_list, rhs_list)

            elif isinstance(exp_dict['rhs'], dict):
                rhs_list.append('EMP')
                lhs_list.append(exp_dict['lhs'])
                self.extract_terms_helper(exp_dict['rhs'], lhs_list, op_list, rhs_list)

            else:
                lhs_list.append(exp_dict['lhs'])
                rhs_list.append(exp_dict['rhs'])

    # a method which returns the operator list, lhs and rhs operand
    # the time complexity is same as its helper function
    def extract_terms(self):
        l_list, o_list, r_list = [], [], []
        self.extract_terms_helper(self.expression_dict, l_list, o_list, r_list)
        o_list = self.modify_operator_list(o_list)
        return l_list, o_list, r_list

    # a method which replaces all the string operators into its notation
    def modify_operator_list(self, op_list):
        # update entries in op_list to actual opreators
        for ind in xrange(len(op_list)):
            if op_list[ind] == 'add':
                op_list[ind] = '+'
            elif op_list[ind] == 'subtract':
                op_list[ind] = '-'
            elif op_list[ind] == 'multiply':
                op_list[ind] = '*'
            elif op_list[ind] == 'divide':
                op_list[ind] = '/'
            else:
                op_list[ind] = '='
        return op_list

    # returns the expression in pretty format
    ''' time= O(m); m is number of nested objects in json expression'''
    def pretty_print(self):
        prev_exp = ''
        for ind in xrange(len(self.lhs_list)-1, -1, -1):
            lhs = self.lhs_list[ind]
            op = self.op_list[ind]
            rhs = self.rhs_list[ind]
            if lhs is 'EMP':
                lhs = prev_exp
            elif rhs is 'EMP':
                rhs = prev_exp

            # do not put brackets if ind is 1 or 0
            if ind <= 1:
                prev_exp = str(lhs) + ' ' + str(op) + ' ' + str(rhs)
            else:
                prev_exp = '(' + str(lhs) + ' ' + str(op) + ' ' + str(rhs) + ')'
        return prev_exp

    def get_opposite_operator(self, op):
        opposite_op = {
            '+': '-',
            '-': '+',
            '*': '/',
            '/': '*'
        }
        return opposite_op[op]

    def check_condition(self, ind):
        return self.rhs_list[ind] == 'EMP' or self.rhs_list[ind] == 'x'

    # it converts the expression so that we have 'x' on only one side of exp
    # there canbe several ways but I am gonna use the lhs_list, op_list and
    # rhs_list to perform this, I coult have even used a expression tree to
    # solve this but time and space are same in this case also.
    ''' time complexity = O(m)'''
    def transform_expression(self):
        temp_exp = ''
        sol = ''
        prev_term = self.lhs_list[0] if self.check_condition(0) else self.rhs_list[0]
        # iterating over the lists and forming the rhs part
        for ind in xrange(1, len(self.lhs_list)):
            temp_exp = self.lhs_list[ind] if self.check_condition(ind) else self.rhs_list[ind]
            req_op = self.get_opposite_operator(self.op_list[ind])
            # do not include brackets if ind is at the end
            if ind == len(self.lhs_list) - 1:
                sol = str(prev_term) + ' ' + req_op + ' ' + str(temp_exp)
            else:
                sol = '( ' + str(prev_term) + ' ' + req_op + ' ' + str(temp_exp) + ' )'
            prev_term = sol
        return 'x = ' + sol

    def is_operator(self, inp):
        if inp == '+' or inp == '-' or inp == '*' or inp == '/':
            return True
        else:
            return False

    ''' Time = O(1)'''
    # performs the operation with op1 and op2 as the operand and op as operator
    def evaluate(self, op1, op2, op):
        op1 = float(op1)
        op2 = float(op2)
        res = 0
        if op == '+':
            res = op1 + op2
        elif op == '-':
            res = op1 - op2
        elif op == '*':
            res = op1 * op2
        elif op == '/':
            res = op1 / op2
        return res

    ''' Time complexity= O(n); n is count of operator + operand in expression'''
    ''' Space complexity = O(1); I have not used any stacks'''
    # the logic I have written here may now work for every infix expression
    # because I am not checking for precedence of operators (as I have
    # brackets in the expression)
    def expression_eval(self, exp):
        rhs_exp = exp.split('=')[1]
        rhs_exp = '(' + rhs_exp + ' )'
        exp_elements = rhs_exp.split(' ')
        operator = ''
        op1, op2 = 0, 0
        is_occurred = False
        for val in exp_elements:
            if self.is_operator(val):
                is_occurred = True
                operator = val
            elif val == ')':
                res = self.evaluate(op1, op2, operator)
                op1 = res
            elif val == '(':
                # do nothing
                pass
            else:
                # these are operands
                if is_occurred is True:
                    op2 = val
                else:
                    op1 = val
        return res

    def print_lists(self):
        print self.lhs_list
        print self.op_list
        print self.rhs_list


if __name__ == '__main__':

    # object for JSONExpression for first input
    jsonExp1 = JSONExpression('./input1.json')

    pretty_exp = jsonExp1.pretty_print()
    print '\nPretty Print:', pretty_exp
    transfored_exp = jsonExp1.transform_expression()
    print 'Transformed Expression:', transfored_exp
    result = jsonExp1.expression_eval(transfored_exp)
    print 'Solution of Above Expression is:', result, '\n'
